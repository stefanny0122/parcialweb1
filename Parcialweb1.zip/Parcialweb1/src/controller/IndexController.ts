// src/controller/IndexController.ts
import IndexModel from "../model/IndexModel.js";
import IndexView from "../view/IndexView.js";
import MovieView from "../view/MovieView.js";
import MovieModel from "../model/MovieModel.js";
import MenuView from "../view/MenuView.js";
import MenuModel from "../model/MenuModel.js";

export default class IndexController {
    private view: IndexView;
    private model: IndexModel;

    private movieView: MovieView;
    private movieModel: MovieModel;

    private menuView: MenuView;
    private menuModel: MenuModel;

    constructor(view: IndexView, model: IndexModel) {
        this.view = view;
        this.model = model;

        // Inicializa MovieModel con un arreglo vacío de películas
        this.movieModel = new MovieModel([]);

        // Crea la instancia de MovieView pasando el modelo
        this.movieView = new MovieView(this.movieModel);

        // Inicializa MenuModel con elementos estáticos
        this.menuModel = new MenuModel();

        // Crea la instancia de MenuView pasando el modelo
        this.menuView = new MenuView(
            document.querySelector('menu') as HTMLElement, // Asume que hay un <menu> en el HTML
            this.menuModel
        );

        // Conecta la vista del índice con la vista de películas
        this.view.setMovieView(this.movieView);

        // Conecta la vista del índice con la vista del menú
        this.view.setMenuView(this.menuView);
    }

    // Método para inicializar el controlador
    public async init(): Promise<void> {
        try {
            // Obtiene los datos de películas desde el archivo
            const data = await this.model.getMoviesFromFile();

            // Establece los datos de películas en el modelo
            this.movieModel.setMovies(data);

            // Renderiza el menú
            this.menuView.render();
        } catch (error) {
            console.error("Error al inicializar el controlador:", error);
        }
    }
}


