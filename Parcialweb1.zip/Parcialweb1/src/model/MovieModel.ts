import Movie from "../Types/Movie.js";
import Subject from "../Types/subject.js";

export default class MovieModel extends Subject<MovieModel> {
    private movies: Movie[];

    constructor(movies: Movie[]) {
        super();
        this.movies = movies;
    }

    public setMovies(movies: Movie[]): void {
        this.movies = movies;
        this.notifyAllObservers(); // Notificar a los observadores
    }

    public getMovies(): Movie[] {
        return this.movies;
    }

    public getMovieByTitle(title: string): Movie | undefined {
        return this.movies.find(movie => movie.title.toLowerCase() === title.toLowerCase());
    }

    public getMovieByYear(year: number): Movie | undefined {
        return this.movies.find(movie => movie.year === year);
    }

    public getMovieByExtract(extract: string): Movie | undefined {
        return this.movies.find(movie => movie.extract.toLowerCase() === extract.toLowerCase());
    }
}
