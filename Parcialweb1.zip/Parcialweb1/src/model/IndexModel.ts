import Movie from "../Types/Movie";
import Menu from "../Types/Menu";

export default class IndexModel {
    private movies: Movie[];
    private menus: Menu[];

    constructor() {
        this.movies = [];
        this.menus = [
            { name: 'Home', route: '#home' },
            { name: 'Rentals', route: '#rentals' },
            { name: 'About', route: '#about' },
        ];
    }

    // Inicializa el modelo cargando las películas desde el archivo
    public init = async (): Promise<void> => {
        try {
            this.movies = await this.getMoviesFromFile();
        } catch (error) {
            console.error("Error al inicializar las películas:", error);
            this.movies = []; // Establece un arreglo vacío en caso de error
        }
    }

    // Obtiene las películas desde el archivo JSON
    public getMoviesFromFile = async (): Promise<Movie[]> => {
        try {
            const response = await fetch('./database/movies-2020s.json');
            if (!response.ok) {
                throw new Error(`Error en la respuesta: ${response.status}`);
            }

            const data: Movie[] = await response.json();

            if (!Array.isArray(data)) {
                throw new Error("Formato de datos incorrecto, se esperaba un array.");
            }

            return data;
        } catch (error) {
            console.error("Error al obtener las películas del archivo:", error);
            return []; // Retorna un arreglo vacío en caso de error
        }
    }

    // Devuelve el arreglo de películas
    public getMovies = (): Movie[] => {
        return this.movies;
    }

    // Devuelve el arreglo de menús
    public getMenus = (): Menu[] => {
        return this.menus;
    }
}
