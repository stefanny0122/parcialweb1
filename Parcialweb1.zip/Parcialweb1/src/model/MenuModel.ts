import Menu from "../Types/Menu.js";
import Subject from "../Types/subject.js";

export default class MenuModel extends Subject<MenuModel> {
  private menus: Menu[];

  constructor() {
    super();
    // Inicializa el menú con elementos estáticos
    this.menus = [
      { name: 'Home', route: '#home' },
      { name: 'Rentals', route: '#rentals' },
      { name: 'About', route: '#about' },
    ];
  }

  public getMenus(): Menu[] {
    return this.menus;
  }
}
