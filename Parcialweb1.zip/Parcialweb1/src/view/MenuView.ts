import MenuModel from "../model/MenuModel.js";

export default class MenuView {
  private menuElement: HTMLElement;
  private menuModel: MenuModel;

  constructor(menuElement: HTMLElement, menuModel: MenuModel) {
    this.menuElement = menuElement;
    this.menuModel = menuModel;
    this.render();
  }

  public render(): void {
    const menus = this.menuModel.getMenus();
    this.menuElement.innerHTML = menus.map(menu => {
      const isRentar = menu.name.toLowerCase() === 'rentals'; // Identifica si el menú es 'Rentals'
      return `
        <div class="menu-item">
          ${isRentar ? 
            `<a href="${menu.route}" class="menu-link">${menu.name}</a>` : 
            `<span class="menu-text">${menu.name}</span>`}
        </div>
      `;
    }).join('');
  }
}


