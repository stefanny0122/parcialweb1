import MovieView from "./MovieView.js";
import MovieModel from "../model/MovieModel.js";
import Movie from "../Types/Movie.js";
import MenuModel from "../model/MenuModel.js";
import MenuView from "./MenuView.js";

export default class IndexView {
  private movieView: MovieView | undefined;
  private menuView: MenuView | undefined;

  constructor() {
    const initialMovies: Movie[] = [];
    const movieModel = new MovieModel(initialMovies);
    this.movieView = new MovieView(movieModel);

    // Inicializa el modelo de menú y la vista de menú
    const menuModel = new MenuModel();
    this.menuView = new MenuView(
      document.querySelector('menu') as HTMLElement, // Asume que hay un <menu> en el HTML
      menuModel
    );

    this.render();
  }

  public setMovieView(movieView: MovieView): void {
    this.movieView = movieView;
  }

  public setMenuView(menuView: MenuView): void {
    this.menuView = menuView;
    // Renderiza el menú
    this.menuView.render();
  }

  public async render(): Promise<void> {
    if (this.movieView) {
      const movies = await this.movieView.loadMovies();
      this.movieView.render(movies);
    }

    if (this.menuView) {
      // Renderiza el menú si está presente
      this.menuView.render();
    }
  }
}
