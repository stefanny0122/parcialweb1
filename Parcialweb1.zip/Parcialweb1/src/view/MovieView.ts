import Movie from "../Types/Movie.js";
import Observer from "../Types/Observer.js";
import MovieModel from "../model/MovieModel.js";
//import Utils from "../utils/utils.js";
export default class MovieView extends Observer<MovieModel> {
  private selector: HTMLDivElement;
  private pageSize: number = 10;
  private currentPage: number = 1;
  private supportedExtensions = ['jpeg', 'jpg', 'png']; // Extensiones soportadas

  constructor(subject: MovieModel) {
    super(subject);
    this.selector = document.querySelector('movies') as HTMLDivElement ?? document.createElement('movies');
    console.log('Selector initialized:', this.selector);
    this.loadMovies(); // Cargar las películas en la inicialización
  }

  public async render(movies: Movie[]): Promise<void> {
    console.log('Rendering movies:', movies);
    this.selector.innerHTML = ''; // Limpiar el contenido existente
    if (movies.length === 0) {
      this.selector.textContent = 'No movies available.';
      return;
    }
    this.selector.appendChild(await this.renderMovies(movies));
    this.renderPagination(movies.length);
  }

  public async loadMovies(): Promise<Movie[]> {
    try {
      const response = await fetch('.../build/database/movies-2020s.json');
      console.log('Fetch response status:', response.status); // Verifica el estado de la respuesta
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const movies: Movie[] = await response.json();
      console.log('Movies loaded:', movies);
      (this.subject as MovieModel).setMovies(movies);
      this.render(movies); // Render con las películas cargadas
      return movies;
    } catch (error) {
      console.error('Error loading movies:', error);
      this.selector.textContent = 'Error loading movies.';
      return [];
    }
  }

  public update(): void {
    this.render((this.subject as MovieModel).getMovies());
  }

  private async imageExists(imageUrl: string): Promise<boolean> {
    try {
      console.log(`Checking if image exists: ${imageUrl}`);
      const response = await fetch(imageUrl, { method: 'HEAD' });
      return response.ok;
    } catch (error) {
      console.error('Error checking image existence:', error);
      return false;
    }
  }

  private cleanTitle(title: string): string {
    return title
      .replace(/[^a-zA-Z0-9\s]/g, '')  // Elimina caracteres especiales
      .split(' ').join('_');           // Reemplaza espacios con guiones bajos
  }

  private async getImageSrc(movieTitle: string): Promise<string> {
    const baseName = `${this.cleanTitle(movieTitle)}_poster`;
    for (const ext of this.supportedExtensions) {
      const imagePath = `./img/movies/${baseName}.${ext}`;
      if (await this.imageExists(imagePath)) {
        console.log(`Image found: ${imagePath}`);
        return imagePath;
      }
    }
    console.log('Image not found, using default');
    return './img/movies/not_icon.png';
  }

  private async renderMovies(movies: Movie[]): Promise<HTMLDivElement> {
    const container = document.createElement('div');
    container.className = 'movie-container';

    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    const paginatedMovies = movies.slice(start, end);

    await Promise.all(paginatedMovies.map(async (movie) => {
      const movieDiv = document.createElement('div');
      movieDiv.className = 'movie-card';

      const mediaDiv = document.createElement('div');
      mediaDiv.className = 'movie-media';

      const thumbnail = document.createElement('div');
      thumbnail.className = 'movie-thumbnail';

      const img = document.createElement('img');
      img.src = await this.getImageSrc(movie.title);
      img.alt = movie.title;
      img.width = movie.thumbnail_width;
      img.height = movie.thumbnail_height;
      thumbnail.appendChild(img);

      const score = document.createElement('div');
      score.className = 'movie-rating';
      score.innerHTML = this.renderStars(movie.score);

      const genres = document.createElement('p');
      genres.className = 'movie-genres';
      genres.textContent = `Genres: ${movie.genres.join(', ')}`;

      mediaDiv.appendChild(thumbnail);
      mediaDiv.appendChild(score);
      mediaDiv.appendChild(genres);

      const infoDiv = document.createElement('div');
      infoDiv.className = 'movie-info';

      const title = document.createElement('h2');
      title.textContent = movie.title;
      infoDiv.appendChild(title);

      const year = document.createElement('p');
      year.textContent = `Year: ${movie.year}`;
      infoDiv.appendChild(year);

      const extract = document.createElement('p');
      extract.className = 'movie-synopsis';
      extract.textContent = movie.extract;
      infoDiv.appendChild(extract);

      const cast = document.createElement('p');
      cast.className = 'movie-cast';
      cast.textContent = `Cast: ${movie.cast.join(', ')}`;
      infoDiv.appendChild(cast);

      const actionButton = document.createElement('button');
      actionButton.textContent = `${movie.price} Rent`;
      actionButton.className = "movie-action";
      infoDiv.appendChild(actionButton);

      movieDiv.appendChild(mediaDiv);
      movieDiv.appendChild(infoDiv);

      container.appendChild(movieDiv);
    }));

    return container;
  }

  private renderStars(score: number): string {
    const fullStars = Math.floor(score);
    const halfStar = score % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

    return `
      ${'<span class="star full">&#9733;</span>'.repeat(fullStars)} 
      ${halfStar ? '<span class="star half">&#9733;</span>' : ''} 
      ${'<span class="star empty">&#9734;</span>'.repeat(emptyStars)}
    `;
  }

  private renderPagination(totalMovies: number): void {
    const totalPages = Math.ceil(totalMovies / this.pageSize);
    const maxVisiblePages = 3;
    const pagination = document.createElement('div');
    pagination.className = 'pagination';

    let startPage = 1;

    const renderPageButtons = () => {
        pagination.innerHTML = '';

        const prevButton = document.createElement('button');
        prevButton.textContent = '<';
        prevButton.disabled = startPage === 1;
        prevButton.addEventListener('click', () => {
            if (startPage > 1) {
                startPage--;
                renderPageButtons();
            }
        });
        pagination.appendChild(prevButton);

        for (let i = startPage; i < startPage + maxVisiblePages && i <= totalPages; i++) {
            const button = document.createElement('button');
            button.textContent = i.toString();
            if (i === this.currentPage) {
                button.classList.add('active');
            }
            button.addEventListener('click', () => {
                this.currentPage = i;
                this.render((this.subject as MovieModel).getMovies());
                renderPageButtons();
            });
            pagination.appendChild(button);
        }

        const nextButton = document.createElement('button');
        nextButton.textContent = '>';
        nextButton.disabled = startPage + maxVisiblePages > totalPages;
        nextButton.addEventListener('click', () => {
            if (startPage + maxVisiblePages <= totalPages) {
                startPage++;
                renderPageButtons();
            }
        });
        pagination.appendChild(nextButton);
    };

    renderPageButtons();

    this.selector.appendChild(pagination);
  }
}
