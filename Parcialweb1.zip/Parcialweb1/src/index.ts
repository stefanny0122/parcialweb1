import IndexController from "./controller/IndexController.js";
import IndexModel from "./model/IndexModel.js";
import IndexView from "./view/IndexView.js";

console.log('Hello, Tipe');
const model = new IndexModel ()
const view  = new IndexView ()
const index = new IndexController (view, model)
index.init()