import Observer from './Observer.js';

export default abstract class Subject<T> {
  private observers: Observer<T>[] = [];

  public attach(observer: Observer<T>): void {
    this.observers.push(observer);
  }

  public detach(observer: Observer<T>): void {
    const index = this.observers.indexOf(observer);
    if (index > -1) {
      this.observers.splice(index, 1);
    }
  }

  public notifyAllObservers(): void {
    this.observers.forEach(observer => observer.update());
  }
}
