export default interface Menu {
    name: string;
    route: string;
}