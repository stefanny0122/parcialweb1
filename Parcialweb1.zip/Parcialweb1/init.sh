npm init -y
npx tsc --init
npx tsc -w